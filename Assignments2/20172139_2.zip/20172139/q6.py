import numpy as np
import pandas as pd
from sklearn.datasets import make_blobs
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report
from sklearn import preprocessing

import matplotlib.pyplot as plt


def euclidean_distance(x1, x2):
    """ Calculates the l2 distance between two vectors """
    distance = 0
    # Squared distance between each coordinate
    for i in range(len(x1)):
        distance += np.square((x1[i] - x2[i]))
    return np.sqrt(distance)


class KMeansImplement():


    def __init__(self, k=2, max_iterations=500):
        self.k = k
        self.max_iterations = max_iterations

    def _init_random_centroids(self, X):
        """ Initialize the centroids as k random samples of X"""
        n_samples, n_features = np.shape(X)
        centroids = np.zeros((self.k, n_features))
        for i in range(self.k):
            centroid = X[np.random.choice(range(n_samples))]
            centroids[i] = centroid
        return centroids

    def _closest_centroid(self, sample, centroids):
        """ Return the index of the closest centroid to the sample """
        closest_i = 0
        closest_dist = float('inf')
        for i, centroid in enumerate(centroids):
            distance = euclidean_distance(sample, centroid)
            if distance < closest_dist:
                closest_i = i
                closest_dist = distance
        return closest_i

    def _create_clusters(self, centroids, X):
        """ Assign the samples to the closest centroids to create clusters """       
        clusters = [[] for _ in range(self.k)]
        for sample_i, sample in enumerate(X):
            centroid_i = self._closest_centroid(sample, centroids)
            clusters[centroid_i].append(sample_i)
        return clusters

    def _calculate_centroids(self, clusters, X):
        """ Calculate new centroids as the means of the samples in each cluster  """
        n_features = np.shape(X)[1]
        centroids = np.zeros((self.k, n_features))
        for i, cluster in enumerate(clusters):
            centroid = np.mean(X[cluster], axis=0)
            centroids[i] = centroid
        return centroids

    def _get_cluster_labels(self, clusters, X):
        """ Classify samples as the index of their clusters """
        # One prediction for each sample
        y_pred = np.zeros(np.shape(X)[0])
        for cluster_i, cluster in enumerate(clusters):
            for sample_i in cluster:
                y_pred[sample_i] = cluster_i
        return y_pred

    def predict(self, X):
        """ Do K-Means clustering and return cluster indices """

        # Initialize centroids as k random samples from X
        centroids = self._init_random_centroids(X)

        # Iterate until convergence or for max iterations
        for _ in range(self.max_iterations):
            print(_)
            # Assign samples to closest centroids (create clusters)
            clusters = self._create_clusters(centroids, X)
            # Save current centroids for convergence check
            prev_centroids = centroids
            # Calculate new centroids from the clusters
            centroids = self._calculate_centroids(clusters, X)
            # If no centroids have changed => convergence
            diff = centroids - prev_centroids
            if not diff.any():
                break

        return self._get_cluster_labels(clusters, X)
    
    
#def main():
#    # Load the dataset
#    X, y = make_blobs()
#
#
#    plt.scatter(X[:, 0], X[:, 1], marker='o', c=y,s=25, edgecolor='k')
#    plt.show()
#    # Cluster the data using K-Means
#    clf = KMeansImplement(k=3)
#    y_pred = clf.predict(X)
#
#    plt.scatter(X[:, 0], X[:, 1], marker='o', c=y_pred,s=25, edgecolor='k')
#    plt.show()
#    
#
#    
#    
#if __name__ == "__main__":
#    main()
#        
    
import os    
import pickle


def readText(filename):
    f = open(filename, "r")
    return f.read()


def getDataFrame(data_dir):
    print('Preparing Pandas Dataframe')
    text_list=[]
    tag_list=[]

    for file_name in os.listdir(data_dir):
#        print(file_name)
        tag=file_name.split('_')[1].split('.')[0]
#        print(tag)
        tag_list.append(tag)
        text=readText(os.path.join(data_dir,file_name))
        text_list.append(text)
        
    data = {'text':text_list, 'tag':tag_list}         
    df = pd.DataFrame(data)
    
    return df

data_dir=r'F:\SMAI\Assignment2\dataset'  

df=getDataFrame(data_dir)

    

tfidf = TfidfVectorizer(sublinear_tf=True, min_df=5, norm='l2',lowercase=True , ngram_range=(1, 2), stop_words='english')
X = tfidf.fit_transform(df.text).toarray()
y = df.tag    
 
    

enc = LabelEncoder()
y = enc.fit_transform(y)

 


import time
from sklearn.decomposition import PCA

print("Reducing the dimension "),
tic = time.time()
pca = PCA()
X_train_PCA_temp = pca.fit_transform(X)

toc = time.time()
print("Took: " + str(toc - tic) + " sec")

explained_variance = pca.explained_variance_ratio_
# Calculating optimal k components 
k = 0
total = np.sum(explained_variance)
current_sum = 0
while(current_sum / total < 0.99):
    current_sum += explained_variance[k]
    k += 1

## Applying PCA with k calcuated above
print("Reducing the dimension "),
tic = time.time()
pca = PCA(n_components=k, whiten=True)
X_train_PCA = pca.fit_transform(X)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")


X_train, X_test, y_train, y_test = train_test_split(X_train_PCA,y,test_size=0.25, random_state=2489)    
    
print("Train data: ", X_train.shape)
print("Train labels: ", y_train.shape)
print("Test data: ", X_test.shape)
print("Test labels: ", y_test.shape)


#print('Training using SVM classifier')    

#from sklearn import svm 
#SVM = svm.SVC(C=1.0, kernel='linear', gamma='auto')
#SVM.fit(X_train,y_train)
#y_pred = SVM.predict(X_test)
#
#print('Saving the trained model')    
#
#import pickle
#with open('q5_naive_svm', 'wb') as training_model:
#    pickle.dump(SVM,training_model)
#
#
#print('Training Score')    
#    
#
#acc=accuracy_score(y_test, y_pred)*100
#cm=confusion_matrix(y_test,y_pred)
#cr=classification_report(y_test,y_pred)
#
#
#print('Accuracy Score :\n',acc)
#print('Confusion Matrix:\n',cm)
#print('Classification Report :\n',cr)
#
#print('Laodingsaved model')   
#    
#
#with open('q5_naive_svm', 'rb') as training_model:
#    model = pickle.load(training_model)
#    y_pred = model.predict(X_test)
#    print('Testing Score')    
#    
#    acc=accuracy_score(y_test, y_pred)*100
#    cm=confusion_matrix(y_test,y_pred)
#    cr=classification_report(y_test,y_pred)
#    print('Accuracy Score :\n',acc)
#    print('Confusion Matrix:\n',cm)
#    print('Classification Report :\n',cr)



# Cluster the data using K-Means
clf = KMeansImplement(k=5)
labels_predicted = clf.predict(X_train)


#with open('model_knn', 'wb') as training_model:
#    pickle.dump(clf,training_model)
#
#
#with open('model_knn', 'rb') as training_model:
#    model = pickle.load(training_model)
#    y_pred = model.predict(X_test)
#
#acc=accuracy_score(y_test, y_pred)*100
#print('Accuracy Score :\n',acc)



tag_names=['business', 'entertainment', 'politics', 'sport', 'tech']



    
    
    
    
    