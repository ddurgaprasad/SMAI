# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 21:27:07 2020

@author: E442282
"""

import matplotlib.pyplot as plt
from matplotlib import style
import numpy as np
import pickle
from scipy.stats import norm
np.random.seed(0)



from gmm import *

dataset1=load(r'Datasets/Question-2/dataset1.pkl')
dataset2=load(r'Datasets/Question-2/dataset2.pkl')
dataset3=load(r'Datasets/Question-2/dataset3.pkl')



X=[]
for item in dataset1:
    X.append(item)
for item in dataset2:
    X.append(item)
for item in dataset3:
    X.append(item)    

from sklearn.mixture import GaussianMixture
gmm = GaussianMixture(n_components=4).fit(X)
labels = gmm.predict(X)
plt.scatter(X, len(X) * [1], c=labels, s=40, cmap='viridis');
plt.show()

probs = gmm.predict_proba(X)
print(probs[:5].round(3))

size = 50 * probs.max(1) ** 2  # square emphasizes differences
plt.scatter(X, len(X) * [1], c=labels, cmap='viridis', s=size);
plt.show()
# print the converged log-likelihood value 
print(gmm.lower_bound_) 

# print the number of iterations needed 
# for the log-likelihood value to converge 
print(gmm.n_iter_)



iterations=8
initmean = [-8,8,5]
initprob = [1/3,1/3,1/3]
initvariance = [5,3,1]

X=np.array(X)
flat_list = [item for sublist in X for item in sublist]
flat_list=np.array(flat_list)

gmm1 = GMM1D(flat_list,iterations,initmean,initprob,initvariance)
gmm1.run()

