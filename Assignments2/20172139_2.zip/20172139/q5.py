import pandas as pd
import numpy as np
import time
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import train_test_split
from sklearn import svm 
from sklearn.metrics import accuracy_score


class AuthorClassifier: 
    
    def __init__(self): 
        self.SVM =svm.SVC( C=1.0, kernel='linear', gamma='auto',verbose=True)

    def fit(self,X,y):
        self.SVM.fit(X,y)        
        
    def predict1(self,X):        
        y_pred = self.SVM.predict(X)
        return y_pred
    
      
    def train(self,train_file):
      
        df = pd.read_csv(train_file)
        X=df.text
        y=df.author
        
        enc = LabelEncoder()
        y = enc.fit_transform(y)
    
        #bag of words notation
        count_vect = CountVectorizer()
        X_CV = count_vect.fit_transform(X)
    
        #Word frequency measure
        tfidf_transformer = TfidfTransformer()
        X_TF = tfidf_transformer.fit_transform(X_CV)
        
        X_train, X_test, y_train, y_test = train_test_split(X_TF,y,test_size=0.25, random_state=2489)
        
        self.fit(X_train,y_train)
        
        y_pred=self.predict1(X_train)
        acc=accuracy_score(y_train, y_pred)*100
        print('Training accuracy Score :\n',acc)
    
#    def train(self,train_file):
#      
#        df = pd.read_csv(train_file)
#        tfidf = TfidfVectorizer(sublinear_tf=True, min_df=5, norm='l2',lowercase=True , ngram_range=(1, 2), stop_words='english')
#        X = tfidf.fit_transform(df.text).toarray()
#        y = df.author
#        enc = LabelEncoder()
#        y = enc.fit_transform(y)
#
#                
#        X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.25, random_state=2489)
#        
#        self.fit(X_train,y_train)
#        
#        y_pred=self.predict1(X_train)
#        acc=accuracy_score(y_train, y_pred)*100
#        print('Training accuracy Score :\n',acc)
#        
#    
    def predict(self,test_file):
        df = pd.read_csv(test_file)
        X=df.text
        
        enc = LabelEncoder()
        y = enc.fit_transform(df.author)
        
        count_vect = CountVectorizer()
        X_CV = count_vect.fit_transform(X)
        
        tfidf_transformer = TfidfTransformer()
        X_TF = tfidf_transformer.fit_transform(X_CV)
        
        y_pred=self.predict1(X_TF)
        
        acc=accuracy_score(y, y_pred)*100
        print('Testing accuracy Score :\n',acc)
    
        
        return y_pred
