# -*- coding: utf-8 -*-
"""
Created on Fri Feb 28 08:55:08 2020

@author: E442282
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score,mean_squared_error,mean_absolute_error
from sklearn import preprocessing
from sklearn.linear_model import LinearRegression
from sklearn import metrics

from q4 import Weather as wr

#from regression import LinearRegression

# Reading t
filename=r'Datasets\Question-4\weather.csv'
df = pd.read_csv(filename)
df.head(3)
# data information
df.info()
import seaborn as sns
fig = plt.subplots(figsize = (10,10))
sns.set(font_scale=1.5)
sns.heatmap(df.corr(),square = True,cbar=True,annot=True,annot_kws={'size': 10})
plt.show()

#Dropping unnecessary Columns. (which includes text.)
cols = ['Formatted Date','Summary','Precip Type','Daily Summary','Wind Bearing (degrees)','Visibility (km)']
df = df.drop(cols,axis=1)

fig = plt.subplots(figsize = (10,10))
sns.set(font_scale=1.5)
sns.heatmap(df.corr(),square = True,cbar=True,annot=True,annot_kws={'size': 10})
plt.show()

def plotFeatures(col_list,title):
    plt.figure(figsize=(5, 7))
    for col in col_list:
        plt.plot(df[col],df['Apparent Temperature (C)'],marker='.',linestyle='none')
        plt.title(title % (col))   
        plt.show()
cols=['Temperature (C)',
  'Humidity',
 'Wind Speed (km/h)',
 'Pressure (millibars)']

plotFeatures(cols,"Relationship between %s and Apparent Temperature (C)")

def getOutliers(data):
    outliers=[]
    threshold=3
    mean_1 = np.mean(data)
    std_1 =np.std(data)
    
    for y in data:
        z_score= (y - mean_1)/std_1 
        if np.abs(z_score) > threshold:
            outliers.append(y)
    return outliers


outlier_data = getOutliers(df["Humidity"])
#print (outlier_data)
df = df[df["Humidity"]>max(outlier_data)]
#plt.plot(df['Humidity'],df['Apparent Temperature (C)'],marker='.',linestyle='none')
#plt.title('Relationship between Apparent Temperature (C) and Humidity')   
#plt.show()


#GET CLEAN FEATURES AND TRAGET VARIABLES
X = df[['Temperature (C)','Humidity','Wind Speed (km/h)','Pressure (millibars)']]
y= df['Apparent Temperature (C)']    


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)


print('\nSKLEARN OUTPUT')
print('=============')
# fitting Multiple Linear regression to Training set
regressor =LinearRegression(n_jobs=4,normalize=False)
regressor.fit(X, y)
W=[ float("%.4f" % float(item)) for item in regressor.coef_ ]
W.insert(0,float("%.4f" % float(regressor.intercept_)))
print('Coeff count   :',len(W))
y_pred=regressor.predict(X)
print('Mean Absolute Error: ', metrics.mean_absolute_error(y, y_pred))
print('Mean Squared Error: ', metrics.mean_squared_error(y, y_pred))
print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y, y_pred)))
print('R Square: ', metrics.r2_score(y,y_pred))

print("The linear model is:\n Apparent Temperature (C)= {:.5} + {:.5}*Temparature + {:.5}*Humidity + \
      {:.5}*WindSpeed + {:.5}*Pressure".format(W[0], W[1], W[2], W[3], W[4]))



learning_rate=0.01 
tolerance=0.02
epochs=2000

model4=wr(learning_rate, tolerance, epochs)
W,costs=model4.train(X,y)
y_pred=model4.predict(X)

from q4 import Weather as wr
from q4 import getOutliers
model4 = wr()
model4.train('./Datasets/q4/train.csv') # Path to the train.csv will be provided 
prediction4 = model4.predict('./Datasets/q4/test.csv') # Path to the test.csv will be provided
# prediction4 should be Python 1-D List
'''WE WILL CHECK THE MEAN SQUARED ERROR OF PREDICTIONS WITH THE GROUND TRUTH VALUES'''



print('\nIMPLEMENTATION OUTPUT')
print('=============')
print('Mean Absolute Error: ', metrics.mean_absolute_error(y, y_pred))
print('Mean Squared Error: ', metrics.mean_squared_error(y, y_pred))
print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y, y_pred)))
print('R Square: ', metrics.r2_score(y,y_pred))

print("\nThe linear model is: \nApparent Temperature (C)= {:.5} + {:.5}*Temparature + {:.5}*Humidity + \
      {:.5}*WindSpeed + {:.5}*Pressure".format(W[0], W[1], W[2], W[3], W[4]))


fig, ax = plt.subplots()  
ax.plot(np.arange(epochs), costs, 'r')  
ax.set_xlabel('Epochs')  
ax.set_ylabel('Cost')  
ax.set_title('Error vs. Training Epoch')  








