import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score,mean_squared_error,mean_absolute_error
from sklearn import preprocessing
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.preprocessing import StandardScaler

def getOutliers(data):
    outliers=[]
    threshold=3
    mean_1 = np.mean(data)
    std_1 =np.std(data)        
    for y in data:
        z_score= (y - mean_1)/std_1 
        if np.abs(z_score) > threshold:
            outliers.append(y)
    return outliers

class Weather:
    def __init__(self, learning_rate=0.01, tolerance=0.02, epochs=2000): 
        self.learning_rate=learning_rate
        self.tolerance = tolerance
        self.epochs=epochs # no of iterations for gradient descent
        self.W=[]
    
    def initWeights(self,X):
        #INITALIZE WEIGHTS WITH RANDOM NUMBERS X(1,X1,X2,...) FOR (W0,W1,W2...)
        self.W=np.random.randn(X.shape[1])  
        
    def getCost(self,X,y):
        num_rows =len(y)
        error=X.dot(self.W)-y
        self.J=(1/(2*num_rows))*np.sum(np.square(error))        
        return self.J
    
    def cost_function(X, Y, B):
         m = len(Y)
         J = np.sum((X.dot(B)- Y) ** 2)/(2 * m)
         return J

    def fit(self,X,y):
        num_rows =len(y) #no of rows        
        X = np.c_[np.ones(num_rows),X]
        self.initWeights(X)
        self.costs= []
        for i in range(self.epochs):
            error=X.dot(self.W)-y            
            cost=self.getCost(X,y)
#            if i % 10 == 0:
#                print("Cost at 10 step iteration {0}: {1}".format(i,cost))
            self.costs.append(cost)
            gradient = np.dot(X.T, error)/num_rows          
            self.W=self.W-(self.learning_rate)*gradient
        return self.W,self.costs
         
    def predict1(self,X):
        X = np.c_[np.ones(len(X)),X] 
        y=X.dot(self.W) 
        return y
    
        

 
    
    def train(self,train_file):
        df = pd.read_csv(train_file)
        cols = ['Formatted Date','Summary','Precip Type','Daily Summary','Wind Bearing (degrees)','Visibility (km)']
        df = df.drop(cols,axis=1)
        
        outlier_data = getOutliers(df["Humidity"])
        df = df[df["Humidity"]>max(outlier_data)]
        #GET CLEAN FEATURES AND TRAGET VARIABLES
        X = df[['Temperature (C)','Humidity','Wind Speed (km/h)','Pressure (millibars)']]
        y= df['Apparent Temperature (C)']    
        

        sc = StandardScaler()
        X = sc.fit_transform(X)
        
        self.fit(X,y)

        
    def predict(self,test_file):
        df = pd.read_csv(test_file)
        cols = ['Formatted Date','Summary','Precip Type','Daily Summary','Wind Bearing (degrees)','Visibility (km)']
        df = df.drop(cols,axis=1)
        
        outlier_data = getOutliers(df["Humidity"])
        df = df[df["Humidity"]>max(outlier_data)]
        #GET CLEAN FEATURES AND TRAGET VARIABLES
        X = df[['Temperature (C)','Humidity','Wind Speed (km/h)','Pressure (millibars)']]
#        y= df['Apparent Temperature (C)']    
        
        sc = StandardScaler()
        X = sc.fit_transform(X)
        
        y_pred=self.predict1(X)
        
        return y_pred
        
        
    
    
    
    