
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics

class Airfoil:
    def __init__(self, learning_rate=0.01, tolerance=0.02, epochs=500,random_state=42): 
        self.learning_rate=learning_rate
        self.tolerance = tolerance
        self.epochs=epochs # no of iterations for gradient descent
        self.random_state=random_state
        self.W=[]
    
    def initWeights(self,X):
        #INITALIZE WEIGHTS WITH RANDOM NUMBERS X(1,X1,X2,...) FOR (W0,W1,W2...)
        np.random.seed(self.random_state)
        self.W=np.random.randn(X.shape[1])  
        
    def getCost(self,X,y):
        num_rows =len(y)
        error=X.dot(self.W)-y
        self.J=(1/(2*num_rows))*np.sum(np.square(error))        
        return self.J
    
    def cost_function(X, Y, B):
         m = len(Y)
         J = np.sum((X.dot(B)- Y) ** 2)/(2 * m)
         return J

    def train(self,X,y):
        num_rows =len(y) #no of rows        
        X = np.c_[np.ones(num_rows),X]
        self.initWeights(X)
        self.costs= []
        for i in range(self.epochs):
            error=X.dot(self.W)-y            
            cost=self.getCost(X,y)
#            if i % 10 == 0:
#                print("Cost at 10 step iteration {0}: {1}".format(i,cost))
            self.costs.append(cost)
            gradient = np.dot(X.T, error)/num_rows          
            self.W=self.W-(self.learning_rate)*gradient
        return self.W,self.costs
         
    def predict(self,X):
        X = np.c_[np.ones(len(X)),X] 
        y=X.dot(self.W) 
        return y

