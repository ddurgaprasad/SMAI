# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 11:16:08 2020

@author: E442282
"""

from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error
        

filename= 'C:/SAI/IIIT/2019-20 Semester II (Spring)/Assignment2/Datasets/Question-5/Train(1).csv'
from q5 import AuthorClassifier as ac
auth_classifier = ac()
auth_classifier.train(filename) # Path to the train.csv will be provided
predictions = auth_classifier.predict(filename) # Path to the test.csv will be provided

'''WE WILL CHECK THE PREDICTIONS WITH THE GROUND TRUTH LABELS'''
from sklearn.preprocessing import LabelEncoder
import pandas as pd
df = pd.read_csv(filename)
X=df.text
enc = LabelEncoder()
y = enc.fit_transform(df.author)

acc=accuracy_score(y, predictions)*100
print('Accuracy Score :\n',acc)
enc = LabelEncoder()
y = enc.fit_transform(y)
