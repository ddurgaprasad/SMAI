# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 17:06:21 2020

@author: E442282
"""

from skimage import data
from skimage import transform as tf
from skimage.feature import ORB
from skimage.color import rgb2gray
import matplotlib.pyplot as plt

import pickle
import time
import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score,f1_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.decomposition import PCA
from sklearn import svm 
import sklearn

def unpickle(file):
    """load the cifar-10 data"""

    with open(file, 'rb') as fo:
        _data = pickle.load(fo, encoding='bytes')
    return _data

def load_CIFAR10_Data(data_dir, negatives=False):
    meta_data_dict = unpickle(data_dir + "/batches.meta")
    labels = meta_data_dict[b'label_names']
    labels = np.array(labels)

    # Train data
    X_train = None
    train_filenames = []
    y_train = []

    for i in range(1, 6):
        X_train_dict = unpickle(data_dir + "/data_batch_{}".format(i))
        if i == 1:
            X_train = X_train_dict[b'data']
        else:
            X_train = np.vstack((X_train, X_train_dict[b'data']))
        train_filenames += X_train_dict[b'filenames']
        y_train += X_train_dict[b'labels']

    X_train = X_train.reshape((len(X_train), 3, 32, 32))
    X_train = np.rollaxis(X_train, 1, 4)
    y_train = np.array(y_train)

    # Test data
    X_test_dict = unpickle(data_dir + "/test_batch")
    X_test = X_test_dict[b'data']    
    y_test = X_test_dict[b'labels']

    X_test = X_test.reshape((len(X_test), 3, 32, 32))
    X_test = np.rollaxis(X_test, 1, 4)   
    y_test = np.array(y_test)

    return X_train, y_train,X_test,y_test, labels

cifar_10_dir = r'Datasets\Question-1\cifar-10-batches-py'

X_train, y_train,X_test,y_test, labels=load_CIFAR10_Data(cifar_10_dir)


print("Train data: ", X_train.shape)

print("Train labels: ", y_train.shape)
print("Test data: ", X_test.shape)

print("Test labels: ", y_test.shape)
print("Label names: ", labels.shape)

print('Train Data Sample:')
row=100

print('Size:' + str(X_train[row].shape))
print('Label:' + str(labels[y_train[row]]))
plt.figure(figsize = (1,1))
plt.axis('off')
plt.imshow(X_train[row])
plt.show()

# display some random training images in a 25x25 grid
num_plot = 5
f, ax = plt.subplots(num_plot, num_plot)
for m in range(num_plot):
    for n in range(num_plot):
        idx = np.random.randint(0, X_train.shape[0])
        ax[m, n].imshow(X_train[idx])
        ax[m, n].get_xaxis().set_visible(False)
        ax[m, n].get_yaxis().set_visible(False)
f.subplots_adjust(hspace=0.1)
f.subplots_adjust(wspace=0)
plt.show()

def getImagesAsVectors(X_train, X_test):
    X_train = np.reshape(X_train,(50000,3072))
    X_test = np.reshape(X_test,(10000,3072))
    X_train = X_train.astype('float32')
    X_test = X_test.astype('float32')
    
    # Normalization of pixel values (to [0-1] range)    
    X_train /= 255
    X_test /= 255
    
    return X_train,X_test 

#X_train,X_test=getImagesAsVectors(X_train, X_test)

from sklearn.svm import SVC

def getScore(y_actual,y_pred):
    acc = sklearn.metrics.accuracy_score(y_actual, y_pred)
    f1=sklearn.metrics.f1_score(y_actual, y_pred, average='micro')
    cm=sklearn.metrics.confusion_matrix(y_actual, y_pred)
    return acc,f1,cm

def getSVMPredictions(X_train, y_train,X_test,y_test,c=0.1):
    ## Training
    clf = SVC(kernel='linear', C=c,verbose=2, class_weight='balanced')
#    clf =  LinearSVC(random_state=0, tol=1e-5,C=0.1,verbose=2)
    clf.fit(X_train, y_train)
    
    filename = 'svm_HOG_PCA_model.pkl'
    pickle.dump(clf, open(filename, 'wb'))
   
    ##Train Scores
    y_pred_train = clf.predict(X_train)
    acc_train,f1_train,cm_train=getScore(y_train,y_pred_train)
    ## Test scores 
    y_pred_test = clf.predict(X_test)
    acc_test,f1_test,cm_test=getScore(y_test,y_pred_test)

    return acc_train,f1_train,cm_train,acc_test,f1_test,cm_test


from skimage.feature import hog

def calcHOG(images):
    hogDescriptors = []    
    for image in images:
        print(len(hogDescriptors))
        gray = rgb2gray(image)
        fd, _ = hog(gray, orientations=8, pixels_per_cell=(8, 8), cells_per_block=(1, 1), visualise=True)
        hogDescriptors.append(fd)        

    hogDescriptors = np.squeeze(hogDescriptors)
    return hogDescriptors


print("Creating HOG descriptors from the training set..."),
tic = time.time()
trainHogDescriptors = calcHOG(X_train)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")


print("Creating HOG descriptors from the test set..."),
tic = time.time()
testHogDescriptors = calcHOG(X_test)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")


print("Reducing the dimension "),
tic = time.time()
pca = PCA()
X_train_PCA_temp = pca.fit_transform(trainHogDescriptors)
X_test_PCA_temp  = pca.fit_transform(testHogDescriptors)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")

explained_variance = pca.explained_variance_ratio_
# Calculating optimal k components 
k = 0
total = np.sum(explained_variance)
current_sum = 0
while(current_sum / total < 0.99):
    current_sum += explained_variance[k]
    k += 1

## Applying PCA with k calcuated above
print("Reducing the dimension "),
tic = time.time()
pca = PCA(n_components=k, whiten=True)
X_train_PCA = pca.fit_transform(trainHogDescriptors)
X_test_PCA = pca.fit_transform(testHogDescriptors)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")
print('Feature count after PCA: ',len(X_train_PCA[0]))


tic = time.time()
n_count=50000
acc_train,f1_train,cm_train,acc_test,f1_test,cm_test=getSVMPredictions(X_train_PCA, y_train,X_test_PCA,y_test)
toc = time.time()
print("Took: " + str(toc - tic) + " sec")

print('Training scores')
print( 'Accuracy: %f' % (acc_train*100 ))
print( 'f1 score: %f' % (f1_train ))
print( 'Confusion matrix :',cm_train)

print('Test scores')
print( 'Accuracy: %f' % (acc_test*100 ))
print( 'f1 score: %f' % (f1_test ))
print( 'Confusion matrix :',cm_test)



#print('Loadingsaved model')   
#with open('svm_HOG_PCA_model.pkl', 'rb') as training_model:
#    model = pickle.load(training_model)
#    y_pred = model.predict(X_test_PCA)
#    print('Testing Score')    
#    
#    acc=accuracy_score(y_test, y_pred)*100
#    cm=confusion_matrix(y_test,y_pred)
#    cr=classification_report(y_test,y_pred)
#    print('Accuracy Score :\n',acc)



