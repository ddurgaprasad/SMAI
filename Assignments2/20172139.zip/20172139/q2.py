# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 11:02:09 2020

@author: E442282
"""

# import the necessary packages
from __future__ import print_function
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score,mean_squared_error,mean_absolute_error,f1_score
from sklearn.preprocessing import LabelEncoder
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


#https://github.com/jwasham/practice-python/blob/master/machine-learning/k-nearest-neighbors.py

class KNNClassifier(object):
    def __init__(self):
        self.X_train = None
        self.y_train = None
        self.X_val = None
        self.y_val = None        
        self.k=1
        self.k_list=[3]
        self.accuracies=[]
        self.conf_matrix=[]
        self.class_report=[]
        self.f1_scores=[]

    def distance(self,f1, f2):    
        assert(len(f1)==len(f2))
        f1 = np.array(f1) 
        f2 = np.array(f2)    
        return np.linalg.norm(f1 - f2)   
    
    def hamming_distance(self,f1, f2):    
        assert(len(f1)==len(f2))
        f1 = np.array(f1) 
        f2 = np.array(f2) 
        dist =sum(c1!=c2 for c1, c2 in zip(f1,f2)) 

        return dist

    
    def loadMushroomData(self,filename):    
        '''    
        train.csv:
        Column 1: Prediction label  
        '''    
        print('Loading Mushroom dataset') 
        df = pd.read_csv(filename) # Load the data
        df.columns = ['edible',
        'cap-shape', 'cap-surface', 'cap-color', 'bruises','odor',                   
        'gill-attachment',  'gill-spacing',  'gill-size',   'gill-color',             
        'stalk-shape', 'stalk-root',  'stalk-surface-above-ring','stalk-surface-below-ring',
        'stalk-color-above-ring', 'stalk-color-below-ring', 
        'veil-type','veil-color','ring-number',    'ring-type',  'spore-print-color',      
        'population', 'habitat'] 
                
#        cols=[]
#        for col in df.columns.values:
#            if(len(df[col].unique())==1):
#                cols.append(col)  
        
        print('Cleaning the data')

#        for col in cols:
#            print('Dropping low contribution column:',col)
#            df.drop(col, axis=1, inplace=True)        

#        print('After dropping low contribution columns') 
#        print(df.head()) 
        
        df.replace(to_replace ="?", value = None)
        for column in df.columns:
            df[column].fillna(df[column].mode()[0], inplace=True)
                
#        print('After replacing missing values') 
#        print(df.head())  
     
        X=df.drop('edible',axis=1) #Predictors
        y=df['edible'] #Response

        Encoder_X = LabelEncoder() 
        for col in X.columns:
            X[col] = Encoder_X.fit_transform(X[col])
        Encoder_y=LabelEncoder()
        y = Encoder_y.fit_transform(y)
         
        X=X.values#using min-max normalization
        X=(X-X.min())/(X.max()-X.min())
        
        print(X)
        print(y)

        return X, y 

    def getKNearestNeighbors(self, test_instance):    
        distances = []
        for index in range(len(self.X_train)):
            dist = self.hamming_distance(self.X_train[index],test_instance)            
            distances.append((self.X_train[index], dist, self.y_train[index]))
        distances.sort(key=lambda tup: tup[1])
        neighbors = distances[:self.k]
        return neighbors
    
    def train(self, filename):
        X, y = self.loadMushroomData(filename)        
        print('Number of training samples')
        print(len(X))
        
        #Splitting the given data into train and validation set in 75:25 split
        (X_train, X_val, y_train, y_val) = train_test_split(X, y, test_size=0.25, random_state=42)
        self.X_train = X_train
        self.y_train = y_train
        self.X_val   = X_val
        self.y_val   = y_val

    def predict(self,to_classify):        
       predictions = []
#       count=0
       for row in to_classify:
#            print('\nProcessing row :',count)
            neighbors = self.getKNearestNeighbors(row)
            #neighbors  have a tuple of (img,dist,label) => (row[0],row[1],row[2])
            output_values = [row[2] for row in neighbors]
            label = max(set(output_values), key=output_values.count)
#            count+=1
            predictions.append(label)
       return predictions

    def predict2(self,filename,num_clusters):  
        self.k=num_clusters
        print('Number of test samples')
        X_test= pd.read_csv(filename)   
        Encoder_X = LabelEncoder() 
        for col in X_test.columns:
            X_test[col] = Encoder_X.fit_transform(X_test[col])
        X_test=X_test.values#using min-max normalization
        X_test=(X_test-X_test.min())/(X_test.max()-X_test.min())
        
        print(len(X_test))
        predictions = []
        for row in X_test:            
            neighbors = self.getKNearestNeighbors(row)
            #neighbors  have a tuple of (img,dist,label) => (row[0],row[1],row[2])
            output_values = [row[2] for row in neighbors]
            label = max(set(output_values), key=output_values.count)
            predictions.append(label)
#            print('Predicted ',label)
        return predictions
#    def accuracy_score(actual_labels, pred_labels):
#        accuracy = np.mean(pred_labels == actual_labels)  
#        return accuracy
#        
    # Calculate accuracy percentage
    def getAccuracy(actual, predicted):
    	correct = 0
    	for i in range(len(actual)):
    		if actual[i] == predicted[i]:
    			correct += 1
    	return correct / float(len(actual)) * 100.0
        
        
    def evaluate(self,k_list):        
        
        self.k_list=k_list
        for k in k_list:
            print('\nNum of Clusters:',k)             
            self.k=k
            pred_labels=self.predict(self.X_val)    
            accuracy = np.mean(pred_labels == self.y_val)  
            print('\nValidation Accuracy :',accuracy)
            self.accuracies.append(accuracy)
            self.conf_matrix.append(confusion_matrix(self.y_val, pred_labels))
            self.class_report.append(classification_report(self.y_val, pred_labels))
   
    def getEvaluationMetrics(self):
        
        plt.xlabel('K ')
        plt.ylabel('Accuracy')
        plt.plot( self.k_list,self.accuracies)
#        plt.axis('off') 
        plt.show()
        
        for i in range(len(self.k_list)):
            print('\nNum of Clusters:',self.k_list[i])  
            
            print('\nConfusion matrix:')
            print(self.conf_matrix[i])
            
            print('\nClassification report:')
            print(self.class_report[i])
            