from sklearn.metrics import accuracy_score
#from sklearn.metrics import mean_squared_error
#from random import seed
#from random import randrange
from q1 import KNNClassifier as knc
import pandas as pd

knn_classifier = knc()
knn_classifier.train('./Datasets/q1/train.csv')


k_list=[3,5,7,9,11,13,15]
#
knn_classifier.evaluate(k_list)

knn_classifier.getEvaluationMetrics()

predictions = knn_classifier.predict2('./Datasets/q1/test.csv',3)
#test_labels = list()
#with open("./Datasets/q1/test_labels.csv") as f:
#  for line in f:
#    test_labels.append(int(line))

mnist_test_labels=r'Datasets/q1/test_labels.csv'
print('Number of test labels')
test_labels = pd.read_csv(mnist_test_labels).values 
print(len(test_labels))
print (accuracy_score(test_labels, predictions))


#from q2 import KNNClassifier as knc
#knn_classifier = knc()
#knn_classifier.train('./Datasets/q2/train.csv')
#knn_classifier.evaluate(k_list)
#

#predictions = knn_classifier.predict('./Datasets/q2/test.csv')
#
#mushroom_test_labels=r'Datasets/q1/test_labels.csv'
#print('Number of test labels')
#test_labels = pd.read_csv(mushroom_test_labels).values 
#print(len(test_labels))
#print (accuracy_score(test_labels, predictions))
#



#from q3 import DecisionTree as dtree
#dtree_regressor = dtree()
#dtree_regressor.train('./Datasets/q2/train.csv')
#predictions = dtree_regressor.predict('./Datasets/q2/test.csv')
#test_labels = list()
#with open("./Datasets/q3/train.csv") as f:
#  for line in f:
#    test_labels.append(float(line.split(',')[1]))
#print (mean_squared_error(test_labels, predictions))
