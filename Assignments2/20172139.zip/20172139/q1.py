# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 11:02:09 2020

@author: E442282
"""


# import the necessary packages
from __future__ import print_function
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import operator
from sklearn.metrics import accuracy_score,mean_squared_error,mean_absolute_error,f1_score

#https://github.com/jwasham/practice-python/blob/master/machine-learning/k-nearest-neighbors.py

class KNNClassifier(object):
    def __init__(self):
        self.X_train = None
        self.y_train = None
        self.X_val = None
        self.y_val = None        
        self.k=1
        self.k_list=[3]
        self.accuracies=[]
        self.conf_matrix=[]
        self.class_report=[]
        self.f1_scores=[]

    def distance(self,f1, f2):    
        assert(len(f1)==len(f2))
        f1 = np.array(f1) 
        f2 = np.array(f2)    
        return np.linalg.norm(f1 - f2)    

    def loadMNISTData(self,filename):    
        '''    
        train.csv:
        Column 1: Prediction label
        Column 2-785: Pixel values. 28*28 image flattened into a 784 dimensional vector.    
        '''    
        df = pd.read_csv(filename).values # Load the data
        X, y = df[:, 1:], df[:,0] # separate target from pixels
        
        return X, y 

    def getKNearestNeighbors(self, test_instance):    
#        print('In KNN')
        distances = []
        for index in range(len(self.X_train)):            
            dist = self.distance(self.X_train[index],test_instance)            
            distances.append((self.X_train[index], dist, self.y_train[index]))            
        distances.sort(key=lambda tup: tup[1])
        neighbors = distances[:self.k]        
        return neighbors


    def train(self, filename):
        X, y = self.loadMNISTData(filename)        
        print('Number of training samples')
        print(len(X))
        
        #Splitting the given data into train and validation set in 75:25 split
        (X_train, X_val, y_train, y_val) = train_test_split(X, y, test_size=0.25, random_state=42)

        self.X_train = X_train
        self.y_train = y_train
        self.X_val   = X_val
        self.y_val   = y_val

    def predict(self,to_classify):  
       print('In Predict')
       predictions = []
       for row in to_classify:
            neighbors = self.getKNearestNeighbors(row)
            #neighbors  have a tuple of (img,dist,label) => (row[0],row[1],row[2])
            output_values = [row[2] for row in neighbors]
            label = max(set(output_values), key=output_values.count)
#            print(label)
            predictions.append(label)
       return predictions

    def predict2(self,filename,num_clusters):  
        self.k=num_clusters
        print('Number of test samples')
        X_test = pd.read_csv(filename).values 
        print(len(X_test))
        predictions = []
        for row in X_test:            
            neighbors = self.getKNearestNeighbors(row)
            #neighbors  have a tuple of (img,dist,label) => (row[0],row[1],row[2])
            output_values = [row[2] for row in neighbors]
            label = max(set(output_values), key=output_values.count)
            predictions.append(label)
#            print('Predicted ',label)
        return predictions
        

    # Calculate accuracy percentage
    def getAccuracy(actual, predicted):
        correct = 0
        for i in range(len(actual)):
            if actual[i] == predicted[i]:
                correct += 1
        return correct / float(len(actual)) * 100.0
        
        
    def evaluate(self,k_list):        
        self.k_list=k_list
        for k in k_list:
            print('\nNum of Clusters:',k)             
            self.k=k
            pred_labels=self.predict(self.X_val)    
            accuracy = np.mean(pred_labels == self.y_val)  
            print('\nValidation Accuracy :',accuracy)
            self.accuracies.append(accuracy)
            self.conf_matrix.append(confusion_matrix(self.y_val, pred_labels))
            self.class_report.append(classification_report(self.y_val, pred_labels))
#            self.f1_scores.append(f1_score(self.y_val, pred_labels))

    def getEvaluationMetrics(self):
        plt.xlabel('K ')
        plt.ylabel('Accuracy')
        plt.plot( self.k_list,self.accuracies)
#        plt.axis('off') 
        plt.show()
        
        for i in range(len(self.k_list)):
            print('\nNum of Clusters:',self.k_list[i])  
            
            print('\nConfusion matrix:')
            print(self.conf_matrix[i])
            
            print('\nClassification report:')
            print(self.class_report[i])
            
#            print('\f1_score report:')
#            print(self.f1_scores[i])
# 

